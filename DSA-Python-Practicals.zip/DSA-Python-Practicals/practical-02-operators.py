"""Practical 2: Demonstrate Python operators."""

a = 10
b = 5

print("Values: a =", a, ", b =", b)
print("\nArithmetic Operators")
print("Addition:", a + b)
print("Subtraction:", a - b)
print("Multiplication:", a * b)
print("Division:", a / b)
print("Floor Division:", a // b)
print("Modulus:", a % b)
print("Power:", a ** b)

print("\nRelational Operators")
print("a == b:", a == b)
print("a != b:", a != b)
print("a > b:", a > b)
print("a < b:", a < b)
print("a >= b:", a >= b)
print("a <= b:", a <= b)

print("\nLogical Operators")
print("a > 5 and b < 10:", a > 5 and b < 10)
print("a < 5 or b == 5:", a < 5 or b == 5)
print("not(a == b):", not (a == b))

print("\nBitwise Operators")
print("a & b:", a & b)
print("a | b:", a | b)
print("a ^ b:", a ^ b)
print("a << 1:", a << 1)
print("a >> 1:", a >> 1)

print("\nAssignment Operator")
value = a
value += b
print("After value += b:", value)

print("\nMembership and Identity")
values = [1, 2, 3, 4]
print("2 in values:", 2 in values)
x = 1000
y = x
print("x is y:", x is y)
