"""Practical 10: Manage tasks using stack and queue operations."""

from collections import deque

undo_stack = []
task_queue = deque()

def add_task(task):
    task_queue.append(task)
    undo_stack.append(("add", task))
    print("Task added:", task)

def process_task():
    if not task_queue:
        print("No tasks in queue.")
        return
    task = task_queue.popleft()
    undo_stack.append(("process", task))
    print("Processed task:", task)

def show_tasks():
    if not task_queue:
        print("Task queue is empty.")
    else:
        print("Pending tasks (front to rear):")
        for number, task in enumerate(task_queue, start=1):
            print(f"{number}. {task}")

def show_stack():
    print("Recent task actions (bottom to top):", undo_stack)

while True:
    print("\n=== Task Manager ===")
    print("1. Add task")
    print("2. Process next task")
    print("3. Display pending tasks")
    print("4. Display action stack")
    print("5. Exit")
    choice = input("Enter choice: ").strip()

    if choice == "1":
        task = input("Enter task description: ").strip()
        if task:
            add_task(task)
        else:
            print("Task description cannot be empty.")
    elif choice == "2":
        process_task()
    elif choice == "3":
        show_tasks()
    elif choice == "4":
        show_stack()
    elif choice == "5":
        print("Exiting Task Manager.")
        break
    else:
        print("Invalid choice. Enter a number from 1 to 5.")
