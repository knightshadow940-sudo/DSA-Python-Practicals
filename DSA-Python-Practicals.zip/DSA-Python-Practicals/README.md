# DSA Python Lab Practicals

**Course:** Data Structure using Python Lab  
**Branch/Semester:** CSE (DS), III Semester  
**Session:** 2026–2027  
**College:** J D College of Engineering and Management, Nagpur

This repository contains Python programs for Practicals 1–10, organized as separate `.py` files and based on the supplied DSA Lab Manual.

## Practical List

1. `practical-01-building-blocks.py` — Python building blocks, data types, and basic input/output
2. `practical-02-operators.py` — Arithmetic, relational, logical, bitwise, and assignment operators
3. `practical-03-lists.py` — List operations and built-in list functions
4. `practical-04-tuple-set-dictionary.py` — Tuple, set, and dictionary operations
5. `practical-05-modules.py` — User-defined and built-in modules
6. `practical-06-numpy.py` — NumPy arrays, indexing, slicing, reshaping, and calculations
7. `practical-07-searching.py` — Linear search and binary search
8. `practical-08-linked-lists.py` — Singly, doubly, and circular linked lists
9. `practical-09-stack-infix-postfix.py` — Stack operations and infix-to-postfix conversion
10. `practical-10-task-stack-queue.py` — Task management using stack and queue operations

## Requirements

- Python 3.9 or later recommended.
- Practical 6 requires NumPy. Install it with:
  ```bash
  python -m pip install numpy
  ```
- Practical 5 includes `my_module.py`, which should be kept in the same folder as `practical-05-modules.py`.

## Running a program

Open a terminal in this folder and run, for example:

```bash
python practical-01-building-blocks.py
```

For Practical 6, install NumPy first. All other programs use the Python standard library.

## Notes

- These are learning examples for lab practice. Review and test them before submission.
- Binary search requires sorted input.
