"""Practical 4: Operations on tuple, set, and dictionary."""

# Tuple: ordered and immutable
items = (10, 20, 30, 40)
print("Tuple:", items)
print("Tuple element at index 1:", items[1])
print("Tuple slice [1:3]:", items[1:3])
print("Tuple concatenation:", items + (50, 60))
print("Tuple repetition:", items * 2)

# Set: unique elements
set_a = {1, 2, 3, 4}
set_b = {3, 4, 5, 6}
set_a.add(7)
set_a.discard(2)
print("\nSet A:", set_a)
print("Set B:", set_b)
print("Union:", set_a | set_b)
print("Intersection:", set_a & set_b)
print("Difference A - B:", set_a - set_b)

# Dictionary: key-value pairs
person = {"name": "Aarav", "age": 20, "marks": 85}
print("\nDictionary:", person)
print("Name:", person["name"])
person["marks"] = 90
person["city"] = "Nagpur"
person.pop("age")
print("Updated dictionary:", person)
print("Keys:", list(person.keys()))
print("Values:", list(person.values()))
print("Items:")
for key, value in person.items():
    print(key, ":", value)
