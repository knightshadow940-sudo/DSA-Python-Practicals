"""Practical 3: Perform list operations and use built-in functions."""

numbers = [10, 20, 30, 40, 50]
print("Original list:", numbers)
print("First element:", numbers[0])
print("Last element:", numbers[-1])
print("Slice [1:4]:", numbers[1:4])

numbers[2] = 35
print("After updating index 2:", numbers)

numbers.append(60)
numbers.insert(1, 15)
print("After append and insert:", numbers)

numbers.remove(40)
removed = numbers.pop()
print("After remove(40) and pop():", numbers)
print("Popped value:", removed)

print("Length:", len(numbers))
print("Maximum:", max(numbers))
print("Minimum:", min(numbers))
print("Sum:", sum(numbers))

numbers.sort()
print("Sorted list:", numbers)
numbers.reverse()
print("Reversed list:", numbers)

print("Traversing the list:")
for item in numbers:
    print(item)
