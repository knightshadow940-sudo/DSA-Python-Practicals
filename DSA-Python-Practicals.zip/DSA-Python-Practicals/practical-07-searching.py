"""Practical 7: Linear search and binary search."""

def linear_search(values, target):
    for index, value in enumerate(values):
        if value == target:
            return index
    return -1

def binary_search(sorted_values, target):
    low = 0
    high = len(sorted_values) - 1
    while low <= high:
        middle = (low + high) // 2
        if sorted_values[middle] == target:
            return middle
        if sorted_values[middle] < target:
            low = middle + 1
        else:
            high = middle - 1
    return -1

values = [34, 12, 27, 9, 41, 18]
target = int(input("Enter the number to search: "))

linear_index = linear_search(values, target)
print("List:", values)
print("Linear search index:", linear_index)

sorted_values = sorted(values)
binary_index = binary_search(sorted_values, target)
print("Sorted list for binary search:", sorted_values)
print("Binary search index:", binary_index)
if binary_index == -1:
    print("Value not found.")
else:
    print("Value found at index", binary_index, "in the sorted list.")
