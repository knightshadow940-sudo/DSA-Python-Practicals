"""Practical 9: Stack operations and infix-to-postfix conversion."""

def push(stack, item):
    stack.append(item)

def pop(stack):
    if not stack:
        return None
    return stack.pop()

def precedence(operator):
    return {"+": 1, "-": 1, "*": 2, "/": 2, "%": 2, "^": 3}.get(operator, 0)

def infix_to_postfix(expression):
    stack = []
    output = []
    tokens = expression.replace("(", " ( ").replace(")", " ) ").split()

    for token in tokens:
        if token.isalnum():
            output.append(token)
        elif token == "(":
            stack.append(token)
        elif token == ")":
            while stack and stack[-1] != "(":
                output.append(stack.pop())
            if not stack:
                raise ValueError("Mismatched parentheses")
            stack.pop()
        else:
            while stack and stack[-1] != "(" and (
                precedence(stack[-1]) > precedence(token)
                or (precedence(stack[-1]) == precedence(token) and token != "^")
            ):
                output.append(stack.pop())
            stack.append(token)

    while stack:
        if stack[-1] in "()":
            raise ValueError("Mismatched parentheses")
        output.append(stack.pop())
    return " ".join(output)

stack = []
push(stack, 10)
push(stack, 20)
push(stack, 30)
print("Stack after pushes:", stack)
print("Popped item:", pop(stack))
print("Stack after pop:", stack)

print("\nUse spaces between operands/operators, e.g. A + B * C")
expression = input("Enter an infix expression: ").strip()
try:
    print("Postfix expression:", infix_to_postfix(expression))
except ValueError as error:
    print("Error:", error)
