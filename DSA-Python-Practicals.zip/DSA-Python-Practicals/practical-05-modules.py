"""Practical 5: Use user-defined and built-in Python modules."""

import math
import random
import statistics
import my_module

number = 16
data = [10, 20, 20, 30, 40]

print("Math Module")
print("Square root:", math.sqrt(number))
print("Factorial of 5:", math.factorial(5))
print("2 raised to 3:", math.pow(2, 3))
print("Ceiling of 4.3:", math.ceil(4.3))
print("Floor of 4.3:", math.floor(4.3))

print("\nStatistics Module")
print("Data:", data)
print("Mean:", statistics.mean(data))
print("Median:", statistics.median(data))
print("Mode:", statistics.mode(data))

print("\nRandom Module")
print("Random integer from 1 to 10:", random.randint(1, 10))

print("\nUser-defined Module")
print("Addition:", my_module.add(5, 3))
print("Multiplication:", my_module.multiply(4, 2))
