"""Practical 6: NumPy array creation, indexing, slicing, reshaping, and maths."""

try:
    import numpy as np
except ImportError:
    print("NumPy is not installed. Run: python -m pip install numpy")
    raise SystemExit(1)

array = np.array([10, 20, 30, 40, 50, 60])
print("Array:", array)
print("Zeros:", np.zeros(4, dtype=int))
print("Ones:", np.ones(3, dtype=int))
print("Range:", np.arange(1, 10, 2))

print("\nIndexing")
print("First element:", array[0])
print("Last element:", array[-1])

print("\nSlicing")
print("Elements [1:4]:", array[1:4])

print("\nReshaping")
matrix = np.array([1, 2, 3, 4, 5, 6]).reshape(2, 3)
print(matrix)
print("Element at row 0, column 1:", matrix[0, 1])

print("\nMathematical Operations")
print("Array + 5:", array + 5)
print("Array * 2:", array * 2)
print("Sum:", np.sum(array))
print("Mean:", np.mean(array))
print("Maximum:", np.max(array))
