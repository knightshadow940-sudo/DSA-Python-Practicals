"""Practical 1: Python building blocks, data types, and basic I/O."""

print("=== Python Basic Data System ===")
name = input("Enter your name: ").strip()
roll_no = input("Enter your roll number: ").strip()

try:
    age = int(input("Enter your age: "))
    marks = float(input("Enter marks out of 100: "))
except ValueError:
    print("Invalid input: age must be an integer and marks must be numeric.")
    raise SystemExit(1)

passed =  marks >= 40
percentage = marks  # marks are assumed to be out of 100

print("\n=== Details ===")
print("Name:", name)
print("Roll Number:", roll_no)
print("Age:", age)
print("Marks:", marks)
print("Percentage:", f"{percentage:.2f}%")
print("Result:", "Pass" if passed else "Fail")

print("\n=== Data Types ===")
print("name:", type(name).__name__)
print("roll_no:", type(roll_no).__name__)
print("age:", type(age).__name__)
print("marks:", type(marks).__name__)
print("passed:", type(passed).__name__)
