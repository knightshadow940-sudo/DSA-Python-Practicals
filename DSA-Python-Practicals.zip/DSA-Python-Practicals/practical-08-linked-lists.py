"""Practical 8: Singly, doubly, and circular linked list demonstrations."""

class SinglyNode:
    def __init__(self, data):
        self.data = data
        self.next = None

class SinglyLinkedList:
    def __init__(self):
        self.head = None

    def append(self, data):
        node = SinglyNode(data)
        if self.head is None:
            self.head = node
            return
        current = self.head
        while current.next:
            current = current.next
        current.next = node

    def display(self):
        values, current = [], self.head
        while current:
            values.append(str(current.data))
            current = current.next
        print(" -> ".join(values) if values else "Empty list")

class DoublyNode:
    def __init__(self, data):
        self.data = data
        self.prev = None
        self.next = None

class DoublyLinkedList:
    def __init__(self):
        self.head = None

    def append(self, data):
        node = DoublyNode(data)
        if self.head is None:
            self.head = node
            return
        current = self.head
        while current.next:
            current = current.next
        current.next = node
        node.prev = current

    def display(self):
        values, current = [], self.head
        while current:
            values.append(str(current.data))
            current = current.next
        print(" <-> ".join(values) if values else "Empty list")

class CircularLinkedList:
    def __init__(self):
        self.head = None

    def append(self, data):
        node = SinglyNode(data)
        if self.head is None:
            self.head = node
            node.next = node
            return
        current = self.head
        while current.next != self.head:
            current = current.next
        current.next = node
        node.next = self.head

    def display(self):
        if self.head is None:
            print("Empty list")
            return
        values, current = [], self.head
        while True:
            values.append(str(current.data))
            current = current.next
            if current == self.head:
                break
        print(" -> ".join(values) + " -> (back to head)")

singly = SinglyLinkedList()
doubly = DoublyLinkedList()
circular = CircularLinkedList()

for value in [10, 20, 30]:
    singly.append(value)
    doubly.append(value)
    circular.append(value)

print("Singly linked list:")
singly.display()
print("Doubly linked list:")
doubly.display()
print("Circular linked list:")
circular.display()
